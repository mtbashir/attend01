const fs = require('fs'), vm = require('vm'), assert = require('assert'), path = require('path');
const ctx = { console, Intl, Date, Math, JSON, btoa, atob, String, Number, Array, Object, isFinite, isNaN, parseInt, Infinity };
ctx.globalThis = ctx;
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, 'mock_gas.js'), 'utf8'), ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'src', 'Code.gs'), 'utf8'), ctx);
const run = (s) => vm.runInContext(s, ctx);

run("__setupSheets('2026-09-22')");
const at = (hhmm) => new Date('2026-09-22T' + hhmm + ':00+05:00').getTime();

// 1. Roster: parsing, times, rules, version check
const r = run("getRosterData('none')");
assert.strictEqual(r.students.length, 4);
assert.strictEqual(JSON.stringify(r.timetable.map(t => t.startTime)), JSON.stringify(['09:00', '14:00', '11:00']));
assert.strictEqual(JSON.stringify(r.timetable[1].rules), JSON.stringify([5, 7, 15]));
assert.strictEqual(r.timetable[0].date, '2026-09-22');
assert.strictEqual(r.sections, undefined, 'new clients get no legacy lists');
const nm = run(`getRosterData('${r.version}')`);
assert.ok(nm.notModified && !nm.students, 'unchanged roster -> tiny reply');
const legacy = run("getRosterData()");
assert.ok(legacy.sections && legacy.rollNos.length === 4, 'old page still gets its lists');
console.log('roster ok, version', r.version, 'full reply', JSON.stringify(r).length, 'bytes, notModified reply', JSON.stringify(nm).length, 'bytes');

// 2. Batch recording with status rules (Section A: session 1 at 09:00; session 2 at 14:00)
const ev = (id, type, sec, roll, t, extra) => Object.assign({ eventId: id, eventType: type, section: sec, rollNo: roll, name: 'N', lat: 31.47, lng: 74.40, distanceMeters: 20, accuracy: 12, deviceId: 'DEV-x', deviceTs: t, skewMs: 1000 }, extra || {});
ctx.__batch = [
  ev('e1', 'SIGN_IN', 'BSCS-A', '101', at('09:04')),   // on time
  ev('e2', 'SIGN_IN', 'bscs-a', '102', at('09:06')),   // fined (case-insensitive section)
  ev('e3', 'SIGN_IN', 'BSCS-A', '103', at('09:10')),   // late + fined
  ev('e4', 'SIGN_IN', 'BSCS-A', '104', at('09:20')),   // absent
  ev('e5', 'SIGN_IN', 'BSCS-A', '105', at('13:58')),   // nearest session is 14:00 -> on time, session 2
  ev('e6', 'SIGN_IN', 'BSCS-C', '301', at('09:30')),   // no timetable -> On Time (original fallback)
  ev('e7', 'GPS_PING_2MIN', 'BSCS-A', '101', at('09:14')),
  ev('e8', 'AUTO_LOGOUT_ABSENT', 'BSCS-A', '101', at('09:40')),
  ev('e9', 'SIGN_IN', 'BSCS-A', '=cmd', at('09:00'), { name: '+danger', skewMs: 9 * 60000 }),
];
let res = run('recordAttendanceBatch(__batch)');
assert.ok(Object.values(res.results).every(v => v === 'ok'), JSON.stringify(res.results));
const rows = ctx.__gas.sheets.Sheet2.raw;
assert.strictEqual(rows.length, 10);
assert.strictEqual(rows[0][18], 'Session No', 'new headers added in S..W');
const byId = Object.fromEntries(rows.slice(1).map(x => [x[22], x]));
const st = (id) => [byId[id][13], byId[id][14], byId[id][15], byId[id][16], byId[id][17], byId[id][18]].join('|');
assert.strictEqual(st('e1'), '+4 mins|On Time||||1');
assert.strictEqual(st('e2'), '+6 mins||Fined|||1');
assert.strictEqual(st('e3'), '+10 mins||Fined|Late||1');
assert.strictEqual(st('e4'), '+20 mins||||Absent|1');
assert.strictEqual(st('e5'), '-2 mins|On Time||||2');
assert.strictEqual(st('e6'), '|On Time||||');
assert.strictEqual(byId.e8[17], 'Absent');
assert.strictEqual(byId.e1[1] + ' ' + byId.e1[2] + ' ' + byId.e1[3], '2026-09-22 Tuesday 09:04:00');
assert.strictEqual(byId.e9[5], "'=cmd"); assert.strictEqual(byId.e9[7], "'+danger");
assert.strictEqual(byId.e9[21], 'Device clock ahead by 9 min');
assert.strictEqual(byId.e1[21], 'OK');
console.log('statuses, dates, formula guard, clock check ok');

// 3. Retry of the same events -> duplicates are recognised, no new rows
res = run('recordAttendanceBatch(__batch)');
assert.ok(Object.values(res.results).every(v => v === 'dup'));
assert.strictEqual(rows.length, 10);
console.log('dedup ok');

// 4. Photo: uploaded once, private by default; dup photo not re-uploaded
ctx.__photo = [ev('p1', 'PHOTO_UPLOAD', 'BSCS-A', '101', at('09:30'), { imageBase64: 'data:image/jpeg;base64,' + Buffer.from('fakejpeg').toString('base64') })];
res = run('recordAttendanceBatch(__photo)'); assert.strictEqual(res.results.p1, 'ok');
res = run('recordAttendanceBatch(__photo)'); assert.strictEqual(res.results.p1, 'dup');
assert.strictEqual(ctx.__gas.files.length, 1); assert.ok(!ctx.__gas.files[0].shared);
assert.ok(String(rows[rows.length - 1][11]).startsWith('https://drive.mock/BSCSA_101_'));
console.log('photo ok');

// 5. Old page: legacy single-record call with a day-first locale time string
ctx.__old = { eventType: 'SIGN_IN', section: 'BSCS-B', rollNo: '201', name: 'Hira', lat: 1, lng: 2, distanceMeters: 5, imageBase64: '', deviceId: 'D', deviceTime: '22/09/2026, 11:03:00' };
assert.strictEqual(run('recordAttendance(__old)'), 'SUCCESS');
assert.strictEqual(rows[rows.length - 1][21], 'Old app version');
console.log('legacy call ok (old code would have thrown here on the unparseable date)');

// 6. A bad record fails alone, the rest of the batch still lands
ctx.__mixed = [ev('m1', 'PHOTO_UPLOAD', 'BSCS-A', '101', at('09:31'), { imageBase64: 'data:image/jpeg;base64,%%%notbase64' }), ev('m2', 'GPS_PING_2MIN', 'BSCS-A', '101', at('09:32'))];
ctx.Utilities.base64Decode = (b) => { if (/%/.test(b)) throw new Error('Could not decode string.'); return [1]; };
res = run('recordAttendanceBatch(__mixed)');
assert.ok(res.results.m1.startsWith('error')); assert.strictEqual(res.results.m2, 'ok');
console.log('per-record errors ok:', res.results.m1);

// 7. JSON API used when the page is hosted outside Apps Script (GitHub Pages)
const api = (expr) => { const out = run(expr); assert.strictEqual(out.mime, 'application/json'); return JSON.parse(out.getContent()); };
let j = api("doGet({ parameter: { action: 'ping' } })");
assert.ok(j.ok && j.result.serverTs > 0);
j = api("doGet({ parameter: { action: 'roster', v: 'none' } })");
assert.ok(j.ok && j.result.students.length === 4 && j.result.sections === undefined);
const ver = j.result.version;
j = api(`doGet({ parameter: { action: 'roster', v: '${ver}' } })`);
assert.ok(j.ok && j.result.notModified);
j = api(`doPost({ postData: { contents: JSON.stringify({ action: 'roster', v: '${ver}' }) } })`);
assert.ok(j.ok && j.result.notModified);
const before = rows.length;
ctx.__body = JSON.stringify({ action: 'record', events: [ev('h1', 'SIGN_IN', 'BSCS-A', '101', at('09:03'))] });
j = api('doPost({ postData: { contents: __body } })');
assert.ok(j.ok && j.result.results.h1 === 'ok' && rows.length === before + 1);
j = api('doPost({ postData: { contents: __body } })');
assert.ok(j.ok && j.result.results.h1 === 'dup' && rows.length === before + 1, 'retry over HTTP is not duplicated');
j = api("doPost({ postData: { contents: 'not json' } })");
assert.ok(!j.ok && j.error);
j = api("doGet({ parameter: { action: 'nope' } })");
assert.ok(!j.ok);
assert.ok(run('doGet({ parameter: {} })').setTitle, 'no action -> HTML page as before');
console.log('JSON API ok (ping, roster, notModified, record, dedup, bad input)');

// 8. Class rush: duplicate checking without reading the sheet, busy replies, no repeated Drive upload
const fresh = () => Date.now() - 30000;   // queued a moment ago, as during a rush
ctx.__warm = [ev('w0', 'GPS_PING_2MIN', 'BSCS-A', '101', fresh())];
run('recordAttendanceBatch(__warm)');          // first call of the day fills the caches
const meter = run('__meterReset()');
ctx.__rush = [ev('r1', 'SIGN_IN', 'BSCS-A', '101', fresh()), ev('r2', 'GPS_PING_2MIN', 'BSCS-A', '102', fresh())];
res = run('recordAttendanceBatch(__rush)');
assert.strictEqual(res.results.r1, 'ok');
assert.ok(!meter.cells.sheetRead, 'an upload during the rush reads nothing from the sheet: ' + JSON.stringify(meter));
res = run('recordAttendanceBatch(__rush)');
assert.strictEqual(res.results.r1, 'dup', 'repeat caught from the cache');

// the cache can be dropped at any time; a phone that says it is resending makes the server look at the sheet
ctx.__gas.cache = {};
run("__gas.cache = {}");
ctx.__retry = [Object.assign({}, ctx.__rush[0], { retry: 1 })];
res = run('recordAttendanceBatch(__retry)');
assert.strictEqual(res.results.r1, 'dup', 'repeat still caught after the cache was lost');

// sheet busy: nothing written, the phone is told to wait, and the photo is not sent to Drive twice
const filesBefore = ctx.__gas.files.length, rowsBefore = rows.length;
ctx.__gas.lockHeld = true;
ctx.__busy = [ev('b1', 'PHOTO_UPLOAD', 'BSCS-A', '101', fresh(), { imageBase64: 'data:image/jpeg;base64,' + Buffer.from('jpegbytes').toString('base64') })];
ctx.Utilities.base64Decode = (b) => [1];
res = run('recordAttendanceBatch(__busy)');
assert.ok(res.busy && res.retryAfterMs > 0 && !res.results.b1, 'busy reply, record not confirmed');
assert.strictEqual(rows.length, rowsBefore, 'nothing written while busy');
assert.strictEqual(ctx.__gas.files.length, filesBefore + 1, 'photo had already gone to Drive');
ctx.__gas.lockHeld = false;
res = run('recordAttendanceBatch(__busy)');
assert.strictEqual(res.results.b1, 'ok');
assert.strictEqual(ctx.__gas.files.length, filesBefore + 1, 'retry reused the photo instead of uploading it again');
assert.strictEqual(rows.length, rowsBefore + 1);
console.log('rush ok (cache dedup, busy reply, photo uploaded once)');

// 9. Missing log tab -> fatal (phone keeps retrying, doesn't mark records as bad)
delete ctx.__gas.sheets.Sheet2;
res = run("recordAttendanceBatch([{eventId:'z'}])");
assert.ok(res.fatal);
console.log('\nALL SERVER TESTS PASSED');
